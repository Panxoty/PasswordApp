package com.example.passapp.OpcionesPassword;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.example.passapp.BaseDeDatos.BDHelper;
import com.example.passapp.MainActivity;
import com.example.passapp.R;

public class Agregar_Actualizar_Registro extends AppCompatActivity {
    EditText EtTitulo,EtCuenta,EtNombreUsuario,EtPassword,EtSitioWeb,EtNota;

    String id, titulo, cuenta, nombre_usuario, password, sitio_web, nota, tiempo_registro, tiempo_actualizacion;

    private boolean MODO_EDICION = false;

    private BDHelper bdHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregarr_password);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setTitle("");

        InicializarVariables();

        ObtenerInformacion();
    }
    private void InicializarVariables(){
        EtTitulo = findViewById(R.id.EtTitulo);
        EtCuenta= findViewById(R.id.EtCuenta);
        EtNombreUsuario= findViewById(R.id.EtNombreUsuario);
        EtPassword = findViewById(R.id.EtPassword);
        EtSitioWeb = findViewById(R.id.EtSitioWeb);
        EtNota = findViewById(R.id.EtNota);

        bdHelper = new BDHelper(this);
    }

    private void ObtenerInformacion(){
        Intent intent = getIntent();
        MODO_EDICION = intent.getBooleanExtra("MODO_EDICION",false);

        if (MODO_EDICION ){
            //Verdadero OBTENEMOS LOS DATOS

            id = intent.getStringExtra("ID");
            titulo = intent.getStringExtra("TITULO");
            cuenta = intent.getStringExtra("CUENTA");
            nombre_usuario = intent.getStringExtra("NOMBRE_USUARIO");
            password = intent.getStringExtra("PASSWORD");
            sitio_web = intent.getStringExtra("SITIO_WEB");
            nota = intent.getStringExtra("NOTA");
            tiempo_registro = intent.getStringExtra("T_REGISTRO");
            tiempo_actualizacion = intent.getStringExtra("T_ACTUALIZACION");
            //SETEAMOS LA INFORMACION EN LAS VISTAS
            EtTitulo.setText(titulo);
            EtCuenta.setText(cuenta);
            EtNombreUsuario.setText(nombre_usuario);
            EtPassword.setText(password);
            EtSitioWeb.setText(sitio_web);
            EtNota.setText(nota);


        }else{
            //Falso el usuario agrega nuevo registro


        }
    }

    /*Metodo el cual nos permite realizar el registro de contraseñas*/
    private void Agregar_Actualizar_R(){
        /*Obtenemos datos de entrada*/
        titulo = EtTitulo.getText().toString().trim();
        cuenta = EtCuenta.getText().toString().trim();
        nombre_usuario = EtNombreUsuario.getText().toString().trim();
        password = EtPassword.getText().toString().trim();
        sitio_web = EtSitioWeb.getText().toString().trim();
        nota = EtNota.getText().toString().trim();

        if(MODO_EDICION){
            //Si es verdadero = Actualizar el registro
            /*Tiempo del dispositivo*/
            String tiempo_actual = ""+ System.currentTimeMillis();
            bdHelper.actualizarRegistro(
                    ""+id,
                    "" + titulo,
                    ""+cuenta,
                    "" + nombre_usuario,
                    ""+password,
                    ""+sitio_web,
                    ""+ nota,
                    ""+ tiempo_registro,
                    ""+tiempo_actual
            );
            Toast.makeText(this, "Datos Actualizados con éxito",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Agregar_Actualizar_Registro.this, MainActivity.class));
            finish();

        }else{
            //Agregar un nuevo registro

            /*Establecemos una condicion si el campo titulo esta vacio no se podra realizar el registro*/
            if(!titulo.equals("")){
                /*Obtenemos el tiempo del dispositivo | Para asi añadirlo en la bd tiempo registro*/
                String tiempo = ""+System.currentTimeMillis();
                long id = bdHelper.insertarRegistro(
                        "" + titulo,
                        "" + cuenta,
                        "" + nombre_usuario,
                        "" + password,
                        "" + sitio_web,
                        "" + nota,
                        "" + tiempo,
                        "" + tiempo
                );
                Toast.makeText(this,"Se ha guardado con éxito: " + id,Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Agregar_Actualizar_Registro.this, MainActivity.class)); //PARA QUE NOS DIRIGA AL MAIN CUANDO GUARDEMOS
            }
            else{
                EtTitulo.setError("Campo Obligatorio");
                EtTitulo.setFocusable(true);
            }
        }




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_guardar, menu); /*Se llama el menu guardar para que aparezca en el activity*/
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.Guardar_Password){
            Agregar_Actualizar_R();
        }
        return super.onOptionsItemSelected(item);
    }
}